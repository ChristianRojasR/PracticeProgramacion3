package gusano;

import java.util.List;

public class Grafo{
	private int [][] matAdy;
	private int cantNodos;
	
	Grafo(int nodos) {
		matAdy = new int [nodos][nodos];
		cantNodos = nodos;
	}
	
	public void agregarArista(int i, int val, int j) {
		matAdy[i][j] = val;
		matAdy[j][i] = val;
	}
	
	public int [][] floyd(List<ComputadoraInfectada> list) {
		int [][] dist = new int [cantNodos][cantNodos];
		dist = matAdy.clone();
		
		
		for (int i = 0; i < cantNodos; i++) {
			for (int j = 0; j < cantNodos; j++) {
				if(dist[i][j] == 0 && i != j) {
					dist[i][j] = Integer.MAX_VALUE;
				}
			}
		}
		
		for (int k = 0; k < cantNodos; k++) {
			for (int i = 0; i < cantNodos; i++) {
				for (int j = 0; j < cantNodos; j++) {
					if(		dist[i][j] < Integer.MAX_VALUE && 
							dist[i][k] < Integer.MAX_VALUE && 
							dist[k][j] < Integer.MAX_VALUE) {
						if(dist[i][k] + dist[k][j] < dist[i][j]) {
							dist[i][j] = dist[i][k] + dist[k][j];
						}
					}
					
				}
			}
		}
		
		for (ComputadoraInfectada aux : list) {
			for (int i = 0; i < cantNodos; i++) {
				if(dist[aux.getComp()][i] == aux.getTiempoInfeccion()) {
					
				}
			}
		}
		
		
		return dist;
	}
	
	public void imprimir() {
		for (int i = 0; i < matAdy.length; i++) {
			for (int j = 0; j < matAdy.length; j++) {
				System.out.print(matAdy[i][j] + " ");
			}
			System.out.println();
		}
	}
}
