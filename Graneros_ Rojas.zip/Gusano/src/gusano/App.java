package gusano;

public class App {
	public static void main(String[] args) {

		GestorArchivo arch = new GestorArchivo("caso1");
		Grafo grafo = null;
		
		grafo = arch.procesarArchivo();
		grafo.imprimir();
		
		int [][] res = grafo.floyd(arch.getListComp());
		
		for (int i = 0; i < res.length; i++) {
			for (int j = 0; j < res.length; j++) {
				System.out.print(res[i][j] + " ");
			}
			System.out.println();
		}
		
	}
}
