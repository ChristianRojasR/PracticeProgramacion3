package gusano;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Scanner;

public class GestorArchivo {
	private String nombre;
	private List<ComputadoraInfectada> listComp;
	
	GestorArchivo(String n) {
		nombre = n;
	}
	
	@SuppressWarnings("finally")
	public Grafo procesarArchivo() {
		Scanner arch = null;
		Grafo grafo = null;
		
		try {
			arch = new Scanner(new File("src/Casos de prueba/" + nombre + ".in"));
			
			int cantNodos = arch.nextInt();
			
			List<Nodo> list = new LinkedList<Nodo>();
			PriorityQueue<Integer> cola = new PriorityQueue<Integer>();
			
			for (int i = 0; i < cantNodos; i++) {
				int desde = arch.nextInt()-1;
				int peso = arch.nextInt();
				int hasta = arch.nextInt()-1;
				list.add(new Nodo(desde, peso, hasta));
				cola.add(desde);
				cola.add(hasta);
			}
			
			grafo = new Grafo(cola.poll());
			
			for (Nodo nodo: list) {
				grafo.agregarArista(nodo.getDesde(), nodo.getPeso(), nodo.getHasta());
			}
			
			int compInfectadas = arch.nextInt();
			listComp = new LinkedList<ComputadoraInfectada>();
			for (int i = 0; i < compInfectadas; i++) {
				ComputadoraInfectada aux = new ComputadoraInfectada(arch.nextInt()-1, arch.nextInt());
				listComp.add(aux);
			}
			
		
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if(arch != null) {
				arch.close();
			}
			return grafo;
		}
	}

	public List<ComputadoraInfectada> getListComp() {
		return listComp;
	}
	
}
